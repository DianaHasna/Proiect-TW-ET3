<?php 
session_start();
if(!isset($_SESSION['id'])){
    header("location: ../index.html");
}



global $conn;
include ("connection.php");

$titlu = $_GET["titlu"];

$verifica_titlu = $conn->prepare("SELECT * FROM filme WHERE nume=?");

$verifica_titlu->execute(array($titlu));
$rows1 = $verifica_titlu->rowCount();


if($rows1 != 1){
    echo "<script>alert('Filmul nu este introdus in baza de date!')</script>";
    die("<script>window.open('index2.php','_self')</script>");
}


$result1 = $verifica_titlu->fetch();
$pret = $result1["pret"];
$id_film = $result1["id"];

$id = $_SESSION["id"];

$preluare_info = $conn->prepare("SELECT * FROM utilizatori WHERE id=?");

$preluare_info->execute(array($id)); 
$result2 = $preluare_info->fetch();

$nume = $result2["nume"];
$prenume = $result2["prenume"];
$email = $result2["email"];
$telefon = $result2["telefon"];

?>

<!DOCTYPE html>
<html>
<head>
<title>Rental Form</title>
<link rel="stylesheet" href="../css/form.css">
</head>
<body>
<div class = "sc">
<div align="center"> <h2>Rental Form</h2> </div><br>
<div align="center">
<form action="form2.php" method="get">

  <label for="fname">Nume:</label><br>
  <input name="nume" value=<?php echo $nume ?> readonly></input><br><br>

  <label for="lname">Prenume:</label><br>
  <input name="prenume" value=<?php echo $prenume ?> readonly></input><br><br>

  <label for="email">E-mail:</label><br>
  <input name="email" value=<?php echo $email ?> readonly></input><br><br>

  <label for="tel">Telefon:</label><br>
  <input name="telefon" value=<?php echo $telefon ?> readonly></input><br><br>

  <label for="mname">Titlu Film:</label><br>
  <input name="titlu" type="text" value=<?php echo $titlu ?> readonly></input><br><br>
  
   <label for="pinchiriere">Perioada Inchiriere:</label><br>
   De la <br>
  <input type="date" id="period" name="inceput" 
        placeholder="yyyy-mm-dd" value=""
        min="1997-01-01" max="2030-12-31"><br><br>
  Pana la <br>
  <input type="date" id="period" name="sfarsit" 
        placeholder="yyyy-mm-dd" value=""
        min="1997-01-01" max="2030-12-31"><br><br>
  
  <label for="pret">Pret:</label><br>
  <p name="pret"><?php echo $pret ?></p><br><br>

<input type="text" name="id_film" value=<?php echo $id_film ?> hidden>
<input type="text" name="id" value=<?php echo $id ?> hidden>



 
<button type="submit" name="submit">Inchiriaza</button>
<button type="submit">Inapoi</button>
 </div> 
</form> 
</div>
</body>
</html>
