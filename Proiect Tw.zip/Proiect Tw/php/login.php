<?php
session_start();
include ("connection.php");
global $conn;

$email = $_POST["email"];
$parola = $_POST["password"];

$check_user = $conn->prepare("select * from utilizatori where email=? AND parola=?");

$check_user ->execute(array($email,$parola));

$rows_user = $check_user->rowCount();

if($rows_user == 1){

    $result = $check_user->fetch();
    $_SESSION['id'] = $result['id'];

    $user_id = $result["id"];
    echo "<script>window.open('index2.php', '_self')</script>";
}

if($rows_user != 1)
{
    echo "<script>alert('Credentiale gresite');</script>";
    echo "<script>window.open('../login.html','_self');</script>";
}


