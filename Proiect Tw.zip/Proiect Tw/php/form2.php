
<?php 
session_start();
global $conn;
include("connection.php");

if(isset($_GET["submit"])){
	$nume = $_GET["nume"];
	$prenume = $_GET["prenume"];
	$email = $_GET["email"];
	$telefon = $_GET["telefon"];
	$titlu = $_GET["titlu"];
	$inceput = $_GET["inceput"];
	$sfarsit = $_GET["sfarsit"];
	$id_film = $_GET["id_film"];
	$id = $_GET["id"];
	if($inceput > $sfarsit)
	{
		echo "<script>alert('Va rog sa verificati datele, data de inceput nu poate fi mai recenta decat data de sfarsit!')</script>";
		die("<script>window.open('index2.php','_self')</script>");
	}
	$introducere = $conn->prepare("INSERT INTO inchirieri values(?,?,?,?,?)");
	
	$introducere->execute(array($id_film,$id,$inceput,$sfarsit,"0"));
	die("<script>window.open('index2.php','_self')</script>");
}
