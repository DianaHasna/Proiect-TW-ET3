<?php
include("connection.php");
global $conn;
$nume = $_POST["nume"];
$prenume = $_POST["prenume"];
$telefon = $_POST["telefon"];
$adresa = $_POST["adresa"];
$email = $_POST["email"];
$parola = $_POST["password"];

$check_email1 = $conn->prepare("select * from utilizatori where email=?");
$check_email1->execute(array($email));
$rows1 = $check_email1->rowCount();

if($rows1 == 1){
    echo "<script>alert('Exista un cont cu aceasta adresa de email!')</script>";
    die("<script>window.open('../index.html','_self')</script>");
}


$id_max = $conn->prepare("select * from utilizatori");
$id_max->execute();

$maxim_id = -1;

while($result2 = $id_max->fetch())
{
    if((int)$result2["id"] > $maxim_id)
    {
        $maxim_id = (int)$result2["id"];
    }
}

if($maxim_id == -1) {

    $user_id = "1";
    $insert_user = $conn->prepare("insert into utilizatori values(?,?,?,?,?,?,?)");


    $res = $insert_user->execute(array($user_id,$nume,$prenume,$telefon,$email,$adresa,$parola));


}

else{
    $user_id = $maxim_id + 1;
    $user_id = (string)$user_id;

    $insert_user = $conn->prepare("insert into utilizatori values(?,?,?,?,?,?,?)");

    $res = $insert_user->execute(array($user_id,$nume,$prenume,$telefon,$email,$adresa,$parola));


}
if($res)
    echo "<script>alert('Felicitari, ati fost introdus in baza de date')</script>";

else
    echo "<script>alert('Ne pare rau, inregistrarea a esuat, va rugam sa reveniti mai tarziu!')</script>";

echo "<script>window.open('../index.html','_self')</script>";