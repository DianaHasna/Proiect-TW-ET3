<?php
session_start();
if(!isset($_SESSION['id'])){
    header("location: ../index.html");
}

global $conn;
include ("connection.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="../css/index.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body class = "bag">
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="index2.php">Movie Rental</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="../movies.html">Inchiriere</a></li>
            <li><a href="logout.php">Deconectare</a></li>
        </ul>
    </div>
</nav>


<div class="container">
    <br>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">

            <div class="item active">
                <img src="../imagini/red-notice.jpg" alt="Red-Notice" width="460" height="345">
                <div class="carousel-caption">
                    <h3 class = "p2">Red-Notice</h3>
                    <p class = "p1" >When an Interpol-issued Red Notice the highest level warrant to hunt and capture the world's most wanted goes out,
                        the FBI's top profiler John Hartley (Dwayne Johnson) is on the case.
                    </p>
                </div>
            </div>

            <div class="item">
                <img src="../imagini/Infinite.jpg" alt="Chania" width="460" height="345">
                <div class="carousel-caption">
                    <h3 class = "p2">Infinite</h3>
                    <p class = "p1">A sci-fi, action adaption that examines the concept of reincarnation through remarkable visuals
                        and well-established characters who need to use their memories and past learnt skills to ensure the future is protected from
                        Infinites that seek to end all life on the planet.
                    </p>
                </div>
            </div>

            <div class="item">
                <img src="../imagini/war.jpg" alt="Flower" width="460" height="345">
                <div class="carousel-caption">
                    <h3 class = "p2">The Tomorrow War</h3>
                    <p class = "p1">The world is stunned when a group of time travelers arrive from the year 2051 to deliver an urgent message:
                        Thirty years in the future, mankind is losing a global war against a deadly alien species.
                    </p>
                </div>
            </div>



        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <br><br><br><br><br>
    <table class = "table">
        <thead>
        <tr class = "col" class = "p2"><th colspan = "3"style="text-align:center">
            Vrei sa vizualizezi un film dar nu mai ai rabdare pana la lansare?
        </th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class = "col" class = "p3">
                1
            </td>
            <td class = "p3">
                CREAZA UN CONT  SAU LOGHEAZA-TE IN CEL EXISTENT
            </td>
            <td class = "p3">
                Daca ai deja un cont atunci inseamna ca ne-ai mai vizitat si stii pasii.
                <p> Daca nu detii un cont si doresti sa-ti faci unul apasa <a href = "../signup.html">aici</a> </p>
            </td>
        </tr>
        <tr >
            <td class = "col" class = "p3">
                2
            </td>
            <td class = "p3">
                CAUTA UN FILM
            </td>
            <td class = "p3">
                Dupa ce te-ai logat poti incepe cautarea filmului dorit.
            </td>
        </tr>
        <tr>
            <td class = "col"class = "p3">
                3
            </td>
            <td class = "p3">
                SELECTEAZA FILMUL
            </td>
            <td class = "p3">
                Daca ai luat o decizie cu privire la filmul dorit,da click pe acesta sau intra in sectiunea de "inchirieri"
                <p> pentru a demara procesul de inchiriere.
            </td>
        </tr>


        </tbody>
    </table>
    </table>
    <br>
    <table class="table">
        <thead>
        <tr>
            <th>
                Top
            </th>
            <th>
                Denumire
            </th>
            <th>
                Data lansarii
            </th>
            <th>
                Gen
            </th>
            <th>
                Pret inchiriere
            </th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>
                1
            </td>
            <td>
                <a href="../film.html">Red Notice</a>
            </td>
            <td>
                12/11/2021
            </td>
            <td>
                Comedy-Action
            </td>
            <td>
                20 Ron
            </td>
        </tr>
        <tr class="table-active">
            <td>
                2
            </td>
            <td>
                <a href="../form.html">Infinite</a>
            </td>
            <td>
                01/04/2012
            </td>
            <td>
                SF
            </td>
            <td>
                25 Ron
            </td>
        </tr>
        <tr class="table-success">
            <td>
                3
            </td>
            <td>
                <a href="../form.html">The Tomorrow War</a>
            </td>
            <td>
                02/04/2012
            </td>
            <td>
                SF-Action
            </td>
            <td>
                15 Ron
            </td>
        </tr>
        <tr class="table-warning">
            <td>
                4
            </td>
            <td>
                <a href="../form.html">Central Intelligence</a>
            </td>
            <td>
                03/04/2021
            </td>
            <td>
                Action
            </td>
            <td>
                20 Ron
            </td>
        </tr>
        <tr class="table-danger">
            <td>
                5
            </td>
            <td>
                <a href="../form.html"> Jason Bourne </a>
            </td>
            <td>
                04/04/2012
            </td>
            <td>
                Action
            </td>
            <td>
                25 Ron
            </td>
        </tr>

        </tbody>
    </table>

    <br><br><br>
    <br>

    <div class="row">
        <div class="column">
            <div class="card">
                <p><i class="fa fa-user"></i></p>
                <h3>11+</h3>
                <p >Parteneri</p>
            </div>
        </div>

        <div class="column">
            <div class="card">
                <p><i class="fa fa-check"></i></p>
                <h3>55+</h3>
                <p>Proiecte</p>
            </div>
        </div>

        <div class="column">
            <div class="card">
                <p><i class="fa fa-smile-o"></i></p>
                <h3>100+</h3>
                <p>Clienti fericiti</p>
            </div>
        </div>

        <div class="column">
            <div class="card">
                <p><i class="fa fa-check"></i></p>
                <h3>100+</h3>
                <p>Filme</p>
            </div>
        </div>


    </div>

</div>




</body>
</html>